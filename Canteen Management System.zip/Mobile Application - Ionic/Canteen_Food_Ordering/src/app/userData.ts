export class UserData {

    static userName='';
    static userId=0;

}
