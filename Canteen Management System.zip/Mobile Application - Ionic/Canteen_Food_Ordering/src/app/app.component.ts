import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  public appPages = [
    { title: 'LOGIN', url: '/login', icon: 'log-in' },
    { title: 'REGISTER', url: '/register', icon: 'bag-handle' },
    { title: 'ORDER', url: '/order', icon: 'cart' },
    { title: 'ORDER STATUS', url: '/order-status', icon: 'card' },
    { title: 'PROFILE', url: '/profile', icon: 'person-circle' },
  ];


  constructor() {}
}
