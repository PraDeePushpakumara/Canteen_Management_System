import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { RegisterService } from 'src/app/service/register.service';
import { UserData } from 'src/app/userData';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  email!:string;
  password!:string;
  

  myForm: any;


  constructor(private router:Router,private service: RegisterService, private formBuilder: FormBuilder, private toastController: ToastController) 
  {

  }

  ngOnInit() {
    this.myForm = this.formBuilder.group({
      
      // password: new FormControl('', [Validators.minLength(6),Validators.required,Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/)]),
      password: new FormControl('', Validators.required),
      type: new FormControl('customer'),
      mobileNo: new FormControl('', Validators.required)
      // mobileNo: new FormControl(0, [Validators.required, Validators.pattern(/^\d{10}$/)]),
      

    });
  }

  login() //get all data 
  {
    
    // this.myForm.control['type'].value='Customer';
    let data=this.myForm.value

    this.service.login(data.mobileNo,'Customer',data.password)
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          console.log(JSON.stringify(response));
          if (response.result!=null) {

            UserData.userName=response.result.name;
            UserData.userId=response.result.id;
            console.log("UserId"+UserData.userId)

            this.presentToast('Success')
            this.router.navigateByUrl('/order');
          } else {
            this.presentToast('invalid data');
          }

          this.presentToast('Login error')
        } else {
          this.presentToast('Login error');

        }
      });
  }


  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      position: 'bottom' // You can change the position as per your preference
    });
    toast.present();
  }

}
