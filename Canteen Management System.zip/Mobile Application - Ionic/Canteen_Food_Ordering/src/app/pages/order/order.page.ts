import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ToastController } from '@ionic/angular';
import { OrderService } from 'src/app/service/order.service';
import { UserData } from 'src/app/userData';


@Component({
  selector: 'app-order',
  templateUrl: './order.page.html',
  styleUrls: ['./order.page.scss'],
})
export class OrderPage implements OnInit {

  productsList: any[] = [];
  cart: any[] = [];

  constructor(private service: OrderService, private formBuilder: FormBuilder, private toastController: ToastController) {

  }

  ngOnInit() {
    this.getAllProducts();
  }


  getAllProducts() {
    this.service.getAllProducts()
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          console.log(response);
          if (response) {
            this.makeOrderItemsList(response.result);
          } else {
            this.presentToast('order not saved');
          }

          
        } else {
          this.presentToast('order not saved');

        }
      });

  }


  makeOrderItemsList(data: any[]) {
    data.forEach(product => {
      product.qty = 1;
      product.incart=false;
      // product.image = 'https://www.allrecipes.com/thmb/m2FHNEKsj7QHe2gvU9e3dzKmwUw=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/1073329-belles-hamburger-buns-vrinda-4x3-1-10f86efd183744f0a42d751f7989968a.jpg';
      this.productsList.push(product);
    })

  }

  addtoCart(data: any) {
    let filterCart: any[] = this.cart.filter(dt => dt.productId === data.id)
    if (filterCart.length == 0) {
      this.cart.push(
        {
          id: 0,
          price: data.price,
          quantity: data.qty,
          orderId: 0,
          productId: data.id
        }
      );
      data.incart=true;
    } else {
      this.presentToast('Productr already exsist !')
    }

  }

  removeFromCart(element:any)
  {
    let object=this.cart.filter(obj=>obj.productId===element.id)
    if (object.length>0) {
        this.cart.splice(object[0], 1);
        element.incart=false;
        element.qty=1;
        this.presentToast('Productr removed from cart !')
    }   
  }



  orderSave() //save order
  {

    let orderData = {
      id: 0,
      customerName: UserData.userName,
      status: 'pending',
      date: '',
      estimateTime: new Date().toString

    };

  
    let passData = {
      orderDetails: orderData,
      orderItemDetails: this.cart
    }

    this.service.saveOrder(passData)
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          console.log(response);
          if (response) {
            this.presentToast('order saved');
            this. clearData();
          } else {
            this.presentToast('order not saved');
          }

          this.presentToast('order saved')
        } else {
          this.presentToast('order not saved');

        }
      });
  }

  clearData()
  {
    this.cart=[];
    this.productsList.forEach(product => {
      product.qty = 1;
      product.incart=false; 
    })
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      position: 'bottom' // You can change the position as per your preference
    });
    toast.present();
  }

}
