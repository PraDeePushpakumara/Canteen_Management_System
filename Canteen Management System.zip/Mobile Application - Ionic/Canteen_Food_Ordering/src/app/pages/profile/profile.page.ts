import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import { ToastController } from '@ionic/angular';
import { RegisterService } from 'src/app/service/register.service';
import { UserData } from 'src/app/userData';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {

  myForm: any;

 

  constructor(private service: RegisterService, private formBuilder: FormBuilder, private toastController: ToastController) {

  }

  ngOnInit() {
    this.getById();
    this.myForm = this.formBuilder.group({
      id: new FormControl('0'),
      name: new FormControl(''),
      mobileNo: new FormControl(''),
      email: new FormControl(''),
      address: new FormControl('')
    
  });

  
}

  data: any= "";

  getById() {
    this.service.getById(UserData.userId)
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          console.log(JSON.stringify(response));
          this.data=response.result;
        

          
        } else {
          // this.presentToast('Data not found');

        }
      });

  }

}
