import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { RegisterService } from 'src/app/service/register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {

  myForm: any;

  constructor(private router:Router,private service: RegisterService, private formBuilder: FormBuilder, private toastController: ToastController) 
  {

  }


  ngOnInit() {
    this.myForm = this.formBuilder.group({
      id: new FormControl('0'),
      name: new FormControl('', [Validators.required, this.nameValidator]),
      password: new FormControl('', [Validators.minLength(6),Validators.required,Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/)]),
      type: new FormControl('customer', Validators.required),
      mobileNo: new FormControl('', [Validators.required, Validators.pattern(/^\d{10}$/)]),
      email: new FormControl('',Validators.pattern(/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/)),
      address: new FormControl('')

    });
  }

  nameValidator(control: AbstractControl): { [key: string]: any } | null {
    const regex = /^[A-Za-z\s]+$/; // Regular expression allowing only letters and spaces

    if (!regex.test(control.value)) {
      return { invalidName: true };
    }

    return null;
  }

  save(){
    // console.log("From Values"+ JSON.stringify(this.myForm.value));
    this.service.save(this.myForm.value)
    .subscribe(data => {
      let response: any = data;
      if (response.status == 200) {
        this.myForm.reset();//clear form after data save
        this.presentToast('Data Saved');
        this.router.navigateByUrl('/login');
      } else {
        this.presentToast('Data Saved Failed');
      }
    });

  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      position: 'bottom' // You can change the position as per your preference
    });
    toast.present();
  }
  

}
