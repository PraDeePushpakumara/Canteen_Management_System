import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ToastController } from '@ionic/angular';
import { OrderService } from 'src/app/service/order.service';

@Component({
  selector: 'app-order-status',
  templateUrl: './order-status.page.html',
  styleUrls: ['./order-status.page.scss'],
})
export class OrderStatusPage implements OnInit {

  orderList: any[] = [];

  constructor(private service: OrderService, private formBuilder: FormBuilder, private toastController: ToastController) {

  }

  ngOnInit() {
    this.getPendingOrders();
  }



  getPendingOrders() {
    this.service.getPendingOrders()
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          console.log(response);
          if (response) {
            this.makeOrderList(response.result);
          } else {
            this.presentToast('order not saved');
          }

          
        } else {
          this.presentToast('order not saved');

        }
      });

  }

  makeOrderList(orders: any[]) {
    this.orderList = orders;
  }


  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      position: 'bottom' // You can change the position as per your preference
    });
    toast.present();
  }


  orderCancel(order:any) //save order
  {
    let odr={
      id:order.id,
      status:'cancelled'
    };

    this.service.update(odr)
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          console.log(response);
          if (response) {
            this.presentToast('order cancelled');
            this.getPendingOrders();
          } else {
            this.presentToast('order not cancelled');
          }
          this.presentToast('order cancelled')
        } else {
          this.presentToast('order not cancelled');
        }
      });
  }


}
