import { HttpClient, HttpParams} from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class OrderService {

    errorMessage: any;
    private orderSaveUrl = 'http://localhost:8888/orderDetails/addOrderDetails';
    private getAllProductUrl='http://localhost:8888/product/getProducts'
    private getPendingOrdersUrl='http://localhost:8888/orderDetails/getPendingOrders'
    private updateOrderUrl='http://localhost:8888/orderDetails/update'



    constructor(private http: HttpClient) { }


    saveOrder(data:any) {
        return this.http.post(this.orderSaveUrl, data);
    }

    update(data:any) {
        return this.http.put(this.updateOrderUrl, data);
    }

    getPendingOrders()
    {
        return this.http.get(this.getPendingOrdersUrl);

    }

    getAllProducts()
    {
        return this.http.get(this.getAllProductUrl);

    }
    

}