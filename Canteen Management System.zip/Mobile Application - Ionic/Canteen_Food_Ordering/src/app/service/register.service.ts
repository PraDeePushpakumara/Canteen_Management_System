
import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class RegisterService {

    errorMessage: any;
    private getAllUrl = 'http://localhost:8888/user/getUsers';
    private saveUrl = 'http://localhost:8888/user/addUser';
    private updateUrl = 'http://localhost:8888/user/update';
    private deleteUrl = 'http://localhost:8888/user/delete';
    private loginUrl = 'http://localhost:8888/user/login';
    private getByIdUrl = 'http://localhost:8888/user/getUserById';


    constructor(private http: HttpClient) { }

    login(mobileNo: any, type: any, password: any) {

        let params = new HttpParams();
        params = params.append('mobileNo', mobileNo)
            .append('type', type)
            .append('password', password);
        return this.http.get(this.loginUrl, { params: params });
    }


    getById(id:any) {
        let params = new HttpParams();
        params = params.append('id', id)
        return this.http.get(this.getByIdUrl, { params: params });
    }
 

    getAll() {
        return this.http.get(this.getAllUrl);
    }

    save(data: any) {
        return this.http.post(this.saveUrl, data);
    }

    update(data: any) {
        return this.http.put(this.updateUrl, data);
    }

    delete(id: number) {
        let queryParams = new HttpParams()
            .append("id", id);
        return this.http.delete(this.deleteUrl, { params: queryParams });
    }

}