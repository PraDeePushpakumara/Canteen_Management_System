package com.canteen.canteen.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.canteen.canteen.entity.FoodCategory;
import com.canteen.canteen.repository.FoodCategoryRepository;

@Service
public class FoodCategoryService {

	@Autowired
	private FoodCategoryRepository repository;

	public FoodCategory saveFoodCategory(FoodCategory foodCategory) {
		return repository.save(foodCategory);

	}
	
	public List<FoodCategory> getAll() {
		return repository.findAll();

	}
	
	

	public String deleteFoodCategory(int id) {
		repository.deleteById(id);
		return "foodCategory deleted successfully";
	}

	public FoodCategory updateFoodCategory(FoodCategory foodCategory) throws Exception {

		Optional<FoodCategory> foodCategoryData = repository.findById(foodCategory.getId());
		if (foodCategoryData.isPresent()) {
			FoodCategory exisitingFoodCategory = foodCategoryData.get();
			exisitingFoodCategory.setName(foodCategory.getName());
			return repository.save(exisitingFoodCategory);
		}

		throw new Exception("Invalid Id");

	}

}
