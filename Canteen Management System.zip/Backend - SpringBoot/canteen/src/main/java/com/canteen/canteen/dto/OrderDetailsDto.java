package com.canteen.canteen.dto;

import java.sql.Date;

public class OrderDetailsDto {
    private int id;
    private String customerName;
    private String status;
    private Date date;
    private String estimateTime;

 

    public OrderDetailsDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderDetailsDto(int id, String customerName, String status, Date date, String estimateTime) {
        this.id = id;
        this.customerName = customerName;
        this.status = status;
        this.date = date;
        this.estimateTime = estimateTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getEstimateTime() {
        return estimateTime;
    }

    public void setEstimateTime(String estimateTime) {
        this.estimateTime = estimateTime;
    }
}

