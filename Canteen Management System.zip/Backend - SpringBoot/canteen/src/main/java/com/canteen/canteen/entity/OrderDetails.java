package com.canteen.canteen.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table (name = "OderDetails")
public class OrderDetails {

	
	@Id
	@GeneratedValue
	private int id;
	private String customerName;
	private String status;
	private Date date;
	private String estimateTime;
	
	public OrderDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public OrderDetails(int id) {
		super();
		this.id = id;
	}



	public OrderDetails(int id, String customerName, String status, Date date, String estimateTime) {
		super();
		this.id = id;
		this.customerName = customerName;
		this.status = status;
		this.date = date;
		this.estimateTime = estimateTime;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getEstimateTime() {
		return estimateTime;
	}

	public void setEstimateTime(String estimateTime) {
		this.estimateTime = estimateTime;
	}
	
	
	
	

}
