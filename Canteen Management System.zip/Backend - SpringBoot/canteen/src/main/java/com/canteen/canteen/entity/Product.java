package com.canteen.canteen.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
@Table (name = "Product")
public class Product {

	@Id
	@GeneratedValue
	private int id;
	
	//@Column(name = "ct_name", nullable = false,unique = true)
	private String name;
	
	
	private String type;
	private double promotionPrice;
	private int rating;
	private double price;
	private String category;
	private String material;
	private String image;
	@ManyToOne
	@JoinColumn(name = "category_id",nullable = false)
	private FoodCategory catregory;
	
	
	
	
	
	public String getImage() {
		return image;
	}



	public void setImage(String image) {
		this.image = image;
	}



	public Product(int id) {
		super();
		this.id = id;
	}



	//no args constructor
	public Product() {
		super();
	}
	
	
	
	//all args constructor



    //getters setters

	public int getId() {
		return id;
	}
	public Product(int id, String name, String type, double promotionPrice, int rating, double price, String category,
			String material, FoodCategory catregory) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
		this.promotionPrice = promotionPrice;
		this.rating = rating;
		this.price = price;
		this.category = category;
		this.material = material;
		this.catregory = catregory;
	}



	public void setId(int id) {
		this.id = id;
	}
	
	
	public String getName() {
		return name;
	}



	public FoodCategory getCatregory() {
		return catregory;
	}



	public void setCatregory(FoodCategory catregory) {
		this.catregory = catregory;
	}



	public void setName(String name) {
		this.name = name;
	}



	public double getPromotionPrice() {
		return promotionPrice;
	}



	public void setPromotionPrice(double promotionPrice) {
		this.promotionPrice = promotionPrice;
	}



	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	
	
	
}
