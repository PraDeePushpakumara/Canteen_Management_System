package com.canteen.canteen.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.canteen.canteen.entity.Product;


public interface ProductRepository extends JpaRepository<Product,Integer>{
	
	Optional<Product> findByName(String name);
	
	//List<prioduct>findById(int id);
	//	List<prioduct> findByNameAndType(String name,String type);

	
	
}