package com.canteen.canteen.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.canteen.canteen.entity.Inventory;


public interface InventoryRepository extends JpaRepository<Inventory,Integer>{ 

	Optional<Inventory> findByName(String name);
}
