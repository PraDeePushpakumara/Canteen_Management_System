package com.canteen.canteen.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "Inventory")
public class Inventory {

	@Id
	@GeneratedValue
	private int id;
	private String type;
	private int quantity; 
	private String name;
	
	//no args constructor
	public Inventory() {
		super();
	}
	
	//all args constructor
	public Inventory(int id, String type, int quantity, String name) {
		super();
		this.id = id;
		this.type = type;
		this.quantity = quantity;
		this.name = name;
	}
	
	//getters setters
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
