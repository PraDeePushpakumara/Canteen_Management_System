package com.canteen.canteen.service;

import com.canteen.canteen.entity.Product;
import com.canteen.canteen.repository.ProductRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

	@Autowired
	private ProductRepository repository;

	public Product saveProduct(Product product) {
		product.setImage("image");
		return repository.save(product);

	}

	public List<Product> getProducts() {
		return repository.findAll();
	}

	public Product getProductById(int id) throws Exception {
		Optional<Product> product = repository.findById(id);
		if (product.isPresent()) {
			return product.get();
		}
		throw new Exception("Invalid Id");
	}

	public Product getProductByName(String name) throws Exception {

		Optional<Product> product = repository.findByName(name);
		if (product.isPresent()) {
			return product.get();
		}
		throw new Exception("Invalid Id");
	}

	public String deleteProduct(int id) {
		repository.deleteById(id);
		return "product deleted successfully";
	}

	public Product updateProduct(Product product) throws Exception {

		Optional<Product> productData = repository.findById(product.getId());
		if (productData.isPresent()) {
			Product exisitingProduct = productData.get();
			exisitingProduct.setName(product.getName());
			exisitingProduct.setType(product.getType());
			exisitingProduct.setPromotionPrice(product.getPromotionPrice());
			exisitingProduct.setRating(product.getRating());
			exisitingProduct.setPrice(product.getPrice());
			exisitingProduct.setCategory(product.getCategory());
			exisitingProduct.setMaterial(product.getMaterial());
			return repository.save(exisitingProduct);
		}

		throw new Exception("Invalid Id");

	}
}
