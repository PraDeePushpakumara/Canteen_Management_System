package com.canteen.canteen.dto;

import java.util.List;

public class OrderDetailsPrime {

	private OrderDetailsDto orderDetails;
	private List<OrderItemDetailsDto> orderItemDetails;
	
	
	public OrderDetailsPrime() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderDetailsPrime(OrderDetailsDto orderDetails, List<OrderItemDetailsDto> orderItemDetails) {
		super();
		this.orderDetails = orderDetails;
		this.orderItemDetails = orderItemDetails;
	}
	public OrderDetailsDto getOrderDetails() {
		return orderDetails;
	}
	public void setOrderDetails(OrderDetailsDto orderDetails) {
		this.orderDetails = orderDetails;
	}
	public List<OrderItemDetailsDto> getOrderItemDetails() {
		return orderItemDetails;
	}
	public void setOrderItemDetails(List<OrderItemDetailsDto> orderItemDetails) {
		this.orderItemDetails = orderItemDetails;
	}
	
	
}