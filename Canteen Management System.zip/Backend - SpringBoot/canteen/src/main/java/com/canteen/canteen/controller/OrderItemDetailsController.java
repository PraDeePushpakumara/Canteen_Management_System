package com.canteen.canteen.controller;

public class OrderItemDetailsController {

}
