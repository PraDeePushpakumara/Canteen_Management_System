package com.canteen.canteen.utill;

public class CustomResponse {
	
	
	int status;
	Object result;
	String errorMessage;
	
	
	public CustomResponse() {
		super();
	}
	
	public CustomResponse(int status, Object result, String errorMessage) {
		super();
		this.status = status;
		this.result = result;
		this.errorMessage = errorMessage;
	}
	
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Object getResult() {
		return result;
	}
	public void setResult(Object result) {
		this.result = result;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	

}
