package com.canteen.canteen.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.canteen.canteen.entity.User;
import com.canteen.canteen.repository.UserRepository;


@Service
public class UserService {

	@Autowired
	private UserRepository repository;

	public User saveUser(User user) {
		return repository.save(user);

	}

	public List<User> getUser() {
		return repository.findAll();
	}

	public User getUserById(int id) throws Exception {
		Optional<User> user = repository.findById(id);
		if (user.isPresent()) {
			return user.get();
		}
		throw new Exception("Invalid Id");
	}

	public User getUserByName(String name) throws Exception {

		Optional<User> user = repository.findByName(name);
		if (user.isPresent()) {
			return user.get();
		}
		throw new Exception("Invalid Id");
	}

	public String deleteUser(int id) {
		repository.deleteById(id);
		return "User deleted successfully";
	}
	
	public User login(int mobileNo, String type, String password) throws Exception {

		Optional<User> user = repository.findByMobileNoAndTypeAndPassword( mobileNo, type, password);
		if (user.isPresent()) {
			return user.get();
		}else {
			return null;
		}
	}

	public User updateUser(User user) throws Exception {

		Optional<User> userData = repository.findById(user.getId());
		if (userData.isPresent()) {
			User exisitingUser = userData.get();
			exisitingUser.setName(user.getName());
			exisitingUser.setPassword(user.getPassword());
			exisitingUser.setType(user.getType());
			exisitingUser.setMobileNo(user.getMobileNo());
			return repository.save(exisitingUser);
		}

		throw new Exception("Invalid Id");

	}

}
