package com.canteen.canteen.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.canteen.canteen.entity.User;

public interface UserRepository extends JpaRepository<User, Integer> {

	Optional<User> findByName(String name);
	
	Optional<User> findByMobileNoAndTypeAndPassword(int mobileNo, String type, String password);

}
