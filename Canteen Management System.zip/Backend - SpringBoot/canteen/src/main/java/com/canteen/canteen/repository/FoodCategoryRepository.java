package com.canteen.canteen.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.canteen.canteen.entity.FoodCategory;

public interface FoodCategoryRepository extends JpaRepository<FoodCategory, Integer> {

}
