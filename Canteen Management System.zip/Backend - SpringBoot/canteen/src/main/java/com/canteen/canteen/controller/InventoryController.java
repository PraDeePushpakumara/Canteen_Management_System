package com.canteen.canteen.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.canteen.canteen.entity.Inventory;
import com.canteen.canteen.service.InventoryService;
import com.canteen.canteen.utill.CustomResponse;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/inventory")
public class InventoryController {
	
	@Autowired
	private InventoryService service;

	@PostMapping("/addInventory")
	public CustomResponse addInventory(@RequestBody Inventory inventory) {

		try {
			return new CustomResponse(200, service.saveInventory(inventory), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid Inventory Id");
		}
	}
	
	@GetMapping("/getInventory")
	public CustomResponse findAllInventory() {try {
		return new CustomResponse(200, service.getInventory(), "");
	} catch (Exception e) {
		return new CustomResponse(500, null, "get featch error");
	}

	}

	@GetMapping("/getInventoryById")
	public CustomResponse findInventoryById(@RequestParam("id") int id) {
		try {
			return new CustomResponse(200, service.getInventoryById(id), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid Inventory Id");
		}
	}

	@GetMapping("/getInventoryByName")
	public CustomResponse findInventoryByName(@RequestParam("name") String name) {

		try {
			return new CustomResponse(200, service.getInventoryByName(name), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid Inventory Id");
		}
	}

	@PutMapping("/update")
	public CustomResponse updateInventory(@RequestBody Inventory inventory) {

		try {
			return new CustomResponse(200, service.updateInventory(inventory), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid Inventory Id");
		}

	}

	@DeleteMapping("/delete")
	public CustomResponse deleteInventory(@RequestParam("id") int id) {

		try {
			return new CustomResponse(200, service.deleteInventory(id), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid Inventory Id");
		}

	}

}

