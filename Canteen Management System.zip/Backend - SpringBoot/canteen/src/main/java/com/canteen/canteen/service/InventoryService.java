package com.canteen.canteen.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.canteen.canteen.entity.Inventory;
import com.canteen.canteen.repository.InventoryRepository;



@Service
public class InventoryService {

	@Autowired
	private InventoryRepository repository; 
	
	public Inventory saveInventory(Inventory inventory){
		return repository.save(inventory);

	}
	public List<Inventory> getInventory(){
		return repository.findAll();
	}
	

	public Inventory getInventoryById(int id) throws Exception{
	 Optional<Inventory>	inventory=repository.findById(id);
	  if(inventory.isPresent())
	  {
		  return inventory.get();
	  }
        throw new Exception("Invalid Id");		
 	}

	public Inventory getInventoryByName(String name) throws Exception{
		
		  Optional<Inventory>inventory=repository.findByName(name);
		  if(inventory.isPresent())
		  {
			  return inventory.get();
		  }
		  throw new Exception("Invalid Id");		
	}

	public String deleteInventory(int id){
		repository.deleteById(id);
		return "inventory deleted successfully";
	}

	public Inventory updateInventory(Inventory inventory) throws Exception{
		
		 Optional<Inventory>inventoryData=repository.findById(inventory.getId());
		  if(inventoryData.isPresent())
		  {			  
			  Inventory exisitingInventory=inventoryData.get();
				exisitingInventory.setName(inventory.getName());
				exisitingInventory.setType(inventory.getType());
				exisitingInventory.setQuantity(inventory.getQuantity());
				return repository.save(exisitingInventory);
		  }
	
		  throw new Exception("Invalid Id");	

	}
}
