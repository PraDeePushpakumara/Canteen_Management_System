package com.canteen.canteen.service;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.canteen.canteen.dto.OrderDetailsPrime;
import com.canteen.canteen.dto.OrderItemDetailsDto;
import com.canteen.canteen.entity.OrderDetails;
import com.canteen.canteen.entity.OrderItemDetails;
import com.canteen.canteen.entity.Product;
import com.canteen.canteen.repository.OrderDetailsRepository;
import com.canteen.canteen.repository.OrderItemDetailsRepository;

@Service
public class OrderDetailsService {

	@Autowired
	private OrderDetailsRepository repository;
	
	@Autowired
	private OrderItemDetailsRepository repositoryOderItem;
	
	public OrderDetails saveOrderDetails(OrderDetailsPrime orderDetails) {
		
		long millis=System.currentTimeMillis();  
        java.sql.Date date=new java.sql.Date(millis);  
		
		OrderDetails order = repository.save(new OrderDetails(
		 				orderDetails.getOrderDetails().getId(),
						orderDetails.getOrderDetails().getCustomerName(),
						orderDetails.getOrderDetails().getStatus(),
						date,
						orderDetails.getOrderDetails().getEstimateTime()));
		
		for (OrderItemDetailsDto orderItemObj : orderDetails.getOrderItemDetails()) {
			repositoryOderItem.save(new OrderItemDetails(
					orderItemObj.getId(),
					orderItemObj.getPrice(),
					orderItemObj.getQuantity(),
					order,
					new Product(orderItemObj.getProductId())));
		}
		
		return order;

	}

	public List<OrderDetails> getOrderDetails() {
		return repository.findAll();
	}
	
	public List<OrderDetails> getPendingOrders() {
		return repository.findByStatus("pending");
	}
	
	
	public OrderDetails updateOrderDetails(OrderDetails orderDetails) throws Exception {

		Optional<OrderDetails> orderDetailsData = repository.findById(orderDetails.getId());
		if (orderDetailsData.isPresent()) {
			OrderDetails exisitingOrderDetails = orderDetailsData.get();
			exisitingOrderDetails.setStatus(orderDetails.getStatus());
			return repository.save(exisitingOrderDetails);
		}

		throw new Exception("Invalid");

	}
}
