package com.canteen.canteen.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table (name = "OderItemDetails")
public class OrderItemDetails {

	@Id
	@GeneratedValue
	private int id;
	private double price;
	private int quntity;
	
	@ManyToOne
	@JoinColumn(name = "Order_id",nullable = false)
	private OrderDetails orderDetails;
	@ManyToOne
	@JoinColumn(name = "Product_id",nullable = false)
	private Product orderProduct;
	
	
	public OrderItemDetails() {
		super();
		// TODO Auto-generated constructor stub
	}


	public OrderItemDetails(int id, double price, int quntity, OrderDetails orderDetails, Product orderProduct) {
		super();
		this.id = id;
		this.price = price;
		this.quntity = quntity;
		this.orderDetails = orderDetails;
		this.orderProduct = orderProduct;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public int getQuntity() {
		return quntity;
	}


	public void setQuntity(int quntity) {
		this.quntity = quntity;
	}


	public OrderDetails getOrderDetails() {
		return orderDetails;
	}


	public void setOrderDetails(OrderDetails orderDetails) {
		this.orderDetails = orderDetails;
	}


	public Product getOrderProduct() {
		return orderProduct;
	}


	public void setOrderProduct(Product orderProduct) {
		this.orderProduct = orderProduct;
	}


	
	

}
	
	
	
	