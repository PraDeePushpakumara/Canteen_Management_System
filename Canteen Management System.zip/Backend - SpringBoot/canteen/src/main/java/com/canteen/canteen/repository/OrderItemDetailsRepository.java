package com.canteen.canteen.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.canteen.canteen.entity.OrderItemDetails;

public interface OrderItemDetailsRepository extends JpaRepository<OrderItemDetails,Integer>{

}

