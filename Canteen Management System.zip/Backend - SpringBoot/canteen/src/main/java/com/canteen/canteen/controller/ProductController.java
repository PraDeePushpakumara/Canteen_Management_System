package com.canteen.canteen.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.canteen.canteen.entity.Product;
import com.canteen.canteen.service.ProductService;
import com.canteen.canteen.utill.CustomResponse;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private ProductService service;

	@PostMapping("/addProduct")
	public CustomResponse addProduct(@RequestBody Product product) {

		try {
			return new CustomResponse(200, service.saveProduct(product), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid Product Id");
		}
	}

	@GetMapping("/getProducts")
	public CustomResponse findAllProducts() {
		try {
			return new CustomResponse(200, service.getProducts(), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "get featch error");
		}

	}

	@GetMapping("/getProductById")
	public CustomResponse findProductById(@RequestParam("id") int id) {
		try {
			return new CustomResponse(200, service.getProductById(id), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid Product Id");
		}
	}

	@GetMapping("/getProductByName")
	public CustomResponse findProductByName(@RequestParam("name") String name) {

		try {
			return new CustomResponse(200, service.getProductByName(name), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid Product Id");
		}
	}

	@PutMapping("/update")
	public CustomResponse updateProduct(@RequestBody Product product) {

		try {
			return new CustomResponse(200, service.updateProduct(product), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid Product Id");
		}

	}

	@DeleteMapping("/delete")
	public CustomResponse deleteProduct(@RequestParam("id") int id) {

		try {
			return new CustomResponse(200, service.deleteProduct(id), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid Product Id");
		}

	}

}
