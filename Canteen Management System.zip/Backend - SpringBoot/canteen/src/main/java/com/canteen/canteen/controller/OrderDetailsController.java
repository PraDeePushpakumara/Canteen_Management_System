package com.canteen.canteen.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.canteen.canteen.dto.OrderDetailsPrime;
import com.canteen.canteen.entity.OrderDetails;
import com.canteen.canteen.service.OrderDetailsService;
import com.canteen.canteen.utill.CustomResponse;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/orderDetails")
public class OrderDetailsController {

	@Autowired
	private OrderDetailsService service;
	
	@PostMapping("/addOrderDetails")
	public CustomResponse addOrderDetails(@RequestBody OrderDetailsPrime orderDetails) {

		try {
			return new CustomResponse(200, service.saveOrderDetails(orderDetails), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid OrderDetails Id");
		}
	}
	
	
	@PutMapping("/update")
	public CustomResponse updateOrderDetails(@RequestBody OrderDetails orderDetails) {

		try {
			return new CustomResponse(200, service.updateOrderDetails(orderDetails), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid OrderDetails Id");
		}

	}
	
	

	@GetMapping("/getOrderDetails")
	public CustomResponse getOrderDetails( ) {
		try {
			return new CustomResponse(200, service.getOrderDetails(), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid OrderDetails Id");
		}

	}
	
	
	@GetMapping("/getPendingOrders")
	public CustomResponse getPendingOrders( ) {
		try {
			return new CustomResponse(200, service.getPendingOrders(), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid OrderDetails Id");
		}

	}
	
	
}
