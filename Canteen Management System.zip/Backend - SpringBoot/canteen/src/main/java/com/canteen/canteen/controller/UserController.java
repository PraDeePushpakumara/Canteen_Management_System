package com.canteen.canteen.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.canteen.canteen.entity.User;
import com.canteen.canteen.service.UserService;
import com.canteen.canteen.utill.CustomResponse;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService service;

	@PostMapping("/addUser")
	public CustomResponse addUser(@RequestBody User user) {

		try {
			return new CustomResponse(200, service.saveUser(user), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid User Id");
		}
	}

	@GetMapping("/getUsers")
	public CustomResponse findAllUsers() {
		try {
			return new CustomResponse(200, service.getUser(), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "get featch error");
		}

	}

	@GetMapping("/getUserById")
	public CustomResponse findUserById(@RequestParam("id") int id) {
		try {
			return new CustomResponse(200, service.getUserById(id), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid User Id");
		}
	}

	@GetMapping("/getUserByName")
	public CustomResponse findUserByName(@RequestParam("name") String name) {

		try {
			return new CustomResponse(200, service.getUserByName(name), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid Usert Name");
		}
	}
	
	
	@GetMapping("/login")
	public CustomResponse login(
			@RequestParam("mobileNo") int mobileNo,
			@RequestParam("type") String type,
			@RequestParam("password") String password) {

		try {
			return new CustomResponse(200, service.login(mobileNo, type, password), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid Usert Name");
		}
	}
	

	@PutMapping("/update")
	public CustomResponse updateUser(@RequestBody User user) {

		try {
			return new CustomResponse(200, service.updateUser(user), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid User Id");
		}

	}

	@DeleteMapping("/delete")
	public CustomResponse deleteUser(@RequestParam("id") int id) {

		try {
			return new CustomResponse(200, service.deleteUser(id), "");
		} catch (Exception e) {
			return new CustomResponse(500, null, "Invalid User Id");
		}

	}

}
