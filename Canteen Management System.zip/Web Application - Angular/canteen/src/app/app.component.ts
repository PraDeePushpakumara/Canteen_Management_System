import { Component } from '@angular/core';
import { UserData } from './userData';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private router:Router){

  }

  title = 'orderingSystem';
  userName = UserData.userName;
  isUserLogin(){
    if(UserData.userName==''){
      return true;
    }else{
      return false;
    }
  }

  logOut(){
    
    this.router.navigateByUrl('/');
    UserData.userName='';
  }
}


