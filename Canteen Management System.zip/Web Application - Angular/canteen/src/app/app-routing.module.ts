import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {LoginComponent} from "./login/login.component";
import {AddProductComponent} from "./add-product/add-product.component";
import {ManageInventoryComponent} from "./manage-inventory/manage-inventory.component";
import {UserComponent} from "./user/user.component";
import {CustomerComponent} from "./customer/customer.component";
import {FoodCategoryComponent} from "./food-category/food-category.component";
import {OtherDetailsComponent} from "./other-details/other-details.component";

const routes: Routes = [
  {path : "" , component : LoginComponent},
  {path : "addProduct", component : AddProductComponent},
  {path : "inventory", component: ManageInventoryComponent},
  {path : "user", component: UserComponent},
  {path : "customer", component: CustomerComponent},
  {path : "category", component: FoodCategoryComponent},
  {path : "other", component: OtherDetailsComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
