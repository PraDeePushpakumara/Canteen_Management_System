import { Component } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RegisterService } from '../services/register.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UserData } from '../userData';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username : string ="";
  password : string ="";
  show: boolean= false;
  submit(){
    console.log("user name is " + this.username)
    this.clear();
  }
  clear(){
    this.username ="";
    this.password = "";
    this.show = true;
  }

  myForm: any;


  constructor(private router:Router,private service: RegisterService, private formBuilder: FormBuilder,private _snackBar: MatSnackBar)  
  {

  }

  ngOnInit() {
    this.myForm = this.formBuilder.group({
      
      
      password: new FormControl('', Validators.required),
      mobileNo: new FormControl('', Validators.required),
      type:new FormControl('',Validators.required)
      

    });
  }

  login() //get all data 
  {
    
    // this.myForm.control['type'].value='Customer';
    let data=this.myForm.value

    this.service.login(data.mobileNo,data.type,data.password)
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          console.log(JSON.stringify(response));
          if (response.result!=null) {

            UserData.userName=response.result.name;
            // console.log("userName"+UserData.userName);

            this._snackBar.open('Login', 'succcess', {
              duration: 3000
            });
            this.router.navigateByUrl('/other');
          }      else {
            this._snackBar.open('Login','Failed', {
              duration: 3000
            });
          }

        }   
      });
  }






}


