import {Component} from '@angular/core';
import {MatTableDataSource} from "@angular/material/table";
import {MatPaginator} from "@angular/material/paginator";
import { FormBuilder } from '@angular/forms';
import { OrderService } from '../services/order.service';
export interface otherDetail{
  orderNo: string;
  customerName: string;
  date:string;

  select: string;
  estimateTime:string;
}

const ELEMENT_DATA: otherDetail[] = [];
@Component({
  selector: 'app-other-details',
  templateUrl: './other-details.component.html',
  styleUrls: ['./other-details.component.css']
})
export class OtherDetailsComponent {

  orderNo: string = "";
  customerName: string ="";
  date: string = "";
  select: string = "";
  estimateTime: string = "";

  displayedColumns: string[] = [
    "orderNo",
    "customerName",
    "date",
    'status',
    "select",
    "estimateTime",
    'updateBtn'
  ];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  selectionList: string[] = [
    "pending",
    "accept",
    "ready",
    "picked"
  ];

  
  orderList: any[] = [];

  constructor(private service: OrderService, private formBuilder: FormBuilder) {

  }

  
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  someMethod(value: any, element: any) {
    console.log("selected value", value);
    console.log("selected element", element);
    element.status = value;
  }

  ngOnInit() {
    this.getPendingOrders();
  }

  getPendingOrders() {
    this.service.getPendingOrders()
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          console.log(response);
          if (response) {
            this.makeOrderList(response.result);
          } else {
           console.log();
           ('order not saved');
          }

          
        } else {
          console.log();

        }
      });

  }
  makeOrderList(orders: any[]) {


    this.orderList = orders;

    
    this.dataSource = new MatTableDataSource(this.orderList);
  }

  updateStatus(order:any) //save order
  {
    let odr={
      id:order.id,
      status:order.status
    };

    console.log(odr);
    

    this.service.update(odr)
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          console.log(response);
          if (response) {
            this.getPendingOrders();
          } else {
            //this.presentToast('order not cancelled');
          }
         // this.presentToast('order cancelled')
        } else {
         // this.presentToast('order not cancelled');
        }
      });
  }





}


