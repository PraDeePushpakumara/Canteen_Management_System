import { Component } from '@angular/core';
import {MatTableDataSource} from "@angular/material/table";
import { InventoryService } from '../services/inventory.service';
import { FormBuilder, FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

export interface manageInventoryComponent {
  name: string;
  quantity: string;
  type : string;
}
const ELEMENT_DATA: manageInventoryComponent[] = [];


@Component({
  selector: 'app-manage-inventory',
  templateUrl: './manage-inventory.component.html',
  styleUrls: ['./manage-inventory.component.css']
})


export class ManageInventoryComponent {

  myForm: any;
  quantity : string = "";

  name : string ="";

  
  valueOne: string = "";
  valueTwo: string = "";



  constructor(private router:Router,private service: InventoryService, private formBuilder: FormBuilder,private _snackBar: MatSnackBar) 
  {

  }

  inventoryDetails : any=[];

  displayedColumns: string[] = ['name', 'quantity'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  ngOnInit() {
    
    this.myForm = this.formBuilder.group({
      id: new FormControl('0'),
      name: new FormControl(''),
      quantity: new FormControl(''),
      type: new FormControl('')

    });

    this.getAll();
  }


  save(){
    // console.log("From Values"+ JSON.stringify(this.myForm.value));
    this.service.addInventory(this.myForm.value)
    .subscribe(data => {
      let response: any = data;
      if (response.status == 200) {
        console.log(JSON.stringify(response));
        this.inventoryDetails.push(response.result);
        this.dataSource = new MatTableDataSource(this.inventoryDetails);
        this.myForm.reset();//clear form after data save
          this._snackBar.open('data saved', 'succcess', {
            duration: 3000
          });
        }
        // this.router.navigateByUrl('/login');
       else {
        this._snackBar.open('data saved failed','Failed', {
          duration: 3000
        });
      }
    });

  }

  getAll() {

    this.service.getInventory()
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          console.log(response)
          this.inventoryDetails=response.result;
          this.dataSource = new MatTableDataSource(this.inventoryDetails);
        } 
      });

  }


}
