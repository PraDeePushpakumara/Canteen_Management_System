import { Component } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import {MatTableDataSource} from "@angular/material/table";
import { Router } from '@angular/router';
import { ProductService } from '../services/product.service';


export interface addedProductDetails{
  id : string;
  productName : string ;
  productType : string ;

  promotionPrice : string;
  rating : string;

  price : string;



  
}
const ELEMENT_DATA: addedProductDetails[] = [];

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})

export class AddProductComponent {

  myForm: any;
  id : string ="";
  productName : string ="";
  productType : string ="";

  promotionPrice : string ="";
  rating : string = "";

  price : string = "";

  choice: string = "";
  valueOne: string = "";
  valueTwo: string = "";
  raw: string = "";
  finished: string = "";

  options= [
    { "value": "Snack", "name": "valueOne", "label": "Snack" },
    { "value": "Rice", "name": "valueTwo", "label": "Rice" },
    { "value": "Beverage", "name": "valueThree", "label": "Beverage" },
    { "value": "Dessert", "name": "valueFour", "label": "Dessert" }
  ]

  constructor(private router:Router,private service: ProductService, private formBuilder: FormBuilder,private _snackBar: MatSnackBar) 
  {

  }

  productDetails : any=[];

 

  displayedColumns: string[] = ['id', 'name', 'promotionPrice', 'rating', 'price', 'category', 'type'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


  ngOnInit() {
    
    this.myForm = this.formBuilder.group({
      id: new FormControl('0'),
      name: new FormControl(''),
      promotionPrice: new FormControl(''),
      rating: new FormControl(''),
      price: new FormControl(''),
      category: new FormControl(''),
      type: new FormControl('')

    });

    this.getAll();
  }


  save(){
    // console.log("From Values"+ JSON.stringify(this.myForm.value));
    this.service.addProduct(this.myForm.value)
    .subscribe(data => {
      let response: any = data;
      if (response.status == 200) {
        console.log(JSON.stringify(response));
        this.productDetails.push(response.result);
        this.dataSource = new MatTableDataSource(this.productDetails);
        this.myForm.reset();//clear form after data save
          this._snackBar.open('data saved', 'succcess', {
            duration: 3000
          });
        }
        // this.router.navigateByUrl('/login');
       else {
        this._snackBar.open('data saved failed','Failed', {
          duration: 3000
        });
      }
    });

  }

  getAll() {

    this.service.getProducts()
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          console.log(response)
          this.productDetails=response.result;
          this.dataSource = new MatTableDataSource(this.productDetails);
        } 
      });

  }


}
