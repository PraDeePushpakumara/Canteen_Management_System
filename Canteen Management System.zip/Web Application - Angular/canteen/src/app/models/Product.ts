export class product{

     id! : number ;
	 name! : String;
	 type! : String;
	 promotionPrice! : number ;
	 rating! : number ;
	 price! : number ;
	 category! : String;
	 material! : String;
     
}