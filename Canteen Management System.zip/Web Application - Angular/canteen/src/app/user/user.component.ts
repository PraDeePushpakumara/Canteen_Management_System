import { Component } from '@angular/core';
import { FormBuilder, FormControl, Validators, AbstractControl } from '@angular/forms';
import {MatTableDataSource} from "@angular/material/table";
import { Router } from '@angular/router';
import { RegisterService } from '../services/register.service';
import { MatSnackBar } from '@angular/material/snack-bar';

export interface userComponent {
  id: string;
  name: string;
  password : string;

  selectedType : string;

  mobNumber : string;
}
const ELEMENT_DATA: userComponent[] = [];


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent {
  id: string="";
  name: string="";
  password : string="";
  show: boolean= false;

  typeOne : string="";
  typeTwo : string="";
  selectedType : string = "";
  mobNumber : string="";

  myForm: any;

  constructor(private router:Router,private service: RegisterService, private formBuilder: FormBuilder,private _snackBar: MatSnackBar) 
  {

  }

  userData : any=[];

  
  displayedColumns: string[] = ['id', 'name', 'password', 'type', 'mobileNo'];
  dataSource = new MatTableDataSource(this.userData);


  ngOnInit() {
    this.getAll();
    this.myForm = this.formBuilder.group({
      id: new FormControl('0'),
      name: new FormControl('', [Validators.required, this.nameValidator]),
      password: new FormControl('', [Validators.minLength(5),Validators.required,Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/)]),
      type: new FormControl('customer', Validators.required),
      mobileNo: new FormControl('', [Validators.required, Validators.pattern(/^\d{10}$/)]),
      email: new FormControl('',Validators.pattern(/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/)),
      address: new FormControl('')

    });
  }

  nameValidator(control: AbstractControl): { [key: string]: any } | null {
    const regex = /^[A-Za-z\s]+$/; // Regular expression allowing only letters and spaces

    if (!regex.test(control.value)) {
      return { invalidName: true };
    }

    return null;
  }

  save(){
    // console.log("From Values"+ JSON.stringify(this.myForm.value));
    this.service.save(this.myForm.value)
    .subscribe(data => {
      let response: any = data;
      if (response.status == 200) {
        console.log(JSON.stringify(response));
        this.userData.push(response.result);
        this.dataSource = new MatTableDataSource(this.userData);
        this.myForm.reset();//clear form after data save
          this._snackBar.open('data saved');
        }
        // this.router.navigateByUrl('/login');
       else {
        this._snackBar.open('data saved failed');
      }
    });

  }

  getAll() {

    this.service.getAll()
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          console.log(response)
          this.userData=response.result;
          this.dataSource = new MatTableDataSource(this.userData);
        } 
      });

  }

 



}




