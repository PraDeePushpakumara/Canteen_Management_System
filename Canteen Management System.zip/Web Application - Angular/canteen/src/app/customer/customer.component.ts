import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import {MatTableDataSource} from "@angular/material/table";
import { Router } from '@angular/router';
import { RegisterService } from '../services/register.service';

export interface customer{
  cusId : string;
  address: string;
  email: string;

  mobileNumber : string;
  cusName : string;
}

const ELEMENT_DATA: customer[] = [];

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent {



  constructor(private router:Router,private service: RegisterService, private formBuilder: FormBuilder,private _snackBar: MatSnackBar) 
  {

  }

  displayedColumns: string[] = ['id', 'name', 'address', 'email', 'mobileNo'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  customerDetails : any=[];

ngOnInit() {

  this.getAll();
}

getAll() {

  this.service.getAll()
    .subscribe(data => {
      let response: any = data;
      if (response.status == 200) {
        console.log(response)
        this.customerDetails=response.result;
        this.dataSource = new MatTableDataSource(this.customerDetails);
      } 
    });

}


}
