import { HttpClient, HttpParams} from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class InventoryService {

    errorMessage: any;
    private getAllUrl = 'http://localhost:8888/inventory/getInventory';
    private saveUrl = 'http://localhost:8888/inventory/addInventory';
    private updateUrl = 'http://localhost:8888/inventory/update';
    private deleteUrl = 'http://localhost:8888/inventory/delete';

    constructor(private http: HttpClient) { }

    getInventory() {
        return this.http.get(this.getAllUrl);
    }
 
    addInventory(data:any) {
        return this.http.post(this.saveUrl, data);
    }

    update(data:any) {
        return this.http.put(this.updateUrl, data);
    }

    delete(id:number) {
        let queryParams = new HttpParams()
        .append("id", id);
        return this.http.delete(this.deleteUrl,{ params: queryParams });
    }

}