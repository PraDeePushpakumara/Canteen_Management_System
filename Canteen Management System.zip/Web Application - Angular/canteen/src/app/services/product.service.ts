import { HttpClient, HttpParams} from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class ProductService {

    errorMessage: any;
    private getAllUrl = 'http://localhost:8888/product/getProducts';
    private saveUrl = 'http://localhost:8888/product/addProduct';
    private updateUrl = 'http://localhost:8888/product/update';
    private deleteUrl = 'http://localhost:8888/product/delete';

    constructor(private http: HttpClient) { }

    getProducts() {
        return this.http.get(this.getAllUrl);
    }
 
    addProduct(data:any) {
        return this.http.post(this.saveUrl, data);
    }

    update(data:any) {
        return this.http.put(this.updateUrl, data);
    }

    delete(id:number) {
        let queryParams = new HttpParams()
        .append("id", id);
        return this.http.delete(this.deleteUrl,{ params: queryParams });
    }

}