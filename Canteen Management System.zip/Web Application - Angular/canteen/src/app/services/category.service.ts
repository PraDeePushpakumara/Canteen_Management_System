
import { HttpClient, HttpParams} from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class CategoryService {

    errorMessage: any;
    private getAllUrl = 'http://localhost:8888/foodCategory/getAll';
    private saveUrl = 'http://localhost:8888/foodCategory/addFoodCategory';
    private updateUrl = 'http://localhost:8888/foodCategory/update';
    private deleteUrl = 'http://localhost:8888/foodCategory/delete';

    constructor(private http: HttpClient) { }

    getAll() {
        return this.http.get(this.getAllUrl);
    }
 
    save(data:any) {
        return this.http.post(this.saveUrl, data);
    }

    update(data:any) {
        return this.http.put(this.updateUrl, data);
    }

    delete(id:number) {
        let queryParams = new HttpParams()
        .append("id", id);
        return this.http.delete(this.deleteUrl,{ params: queryParams });
    }

}