import { Component } from '@angular/core';
import { manageInventoryComponent } from "../manage-inventory/manage-inventory.component";
import { MatTableDataSource } from "@angular/material/table";
import { CategoryService } from '../services/category.service';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Category } from '../models/Category';
import { SelectionModel } from '@angular/cdk/collections';
import { MatSnackBar } from "@angular/material/snack-bar";

@Component({
  selector: 'app-food-category',
  templateUrl: './food-category.component.html',
  styleUrls: ['./food-category.component.css']
})
export class FoodCategoryComponent {


  myForm: any;
  id: any = ""
  name: any = ""

  selection = new SelectionModel<any>(false, []);
  allData: Category[] = [];
  displayedColumns: string[] = ['select', 'id', 'name'];
  dataSource = new MatTableDataSource(this.allData);

  constructor(private service: CategoryService,private snackBar: MatSnackBar, private formBuilder: FormBuilder) 
  {

  }


  ngOnInit() {
    this.myForm = this.formBuilder.group({
      id: new FormControl('0'),
      name: new FormControl('', Validators.required)
    });
    this.selection.clear();
    this.getData();
  }

  getData() //get all data 
  {
    this.service.getAll()
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          console.log(response);
          this.allData = response.result;
          this.dataSource = new MatTableDataSource(this.allData);
        } else {
          this.alertMessage('Data loading Error','notice');

        }
      });
  }

  save() //save selected data
  {
    this.service.save(this.myForm.value)
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          this.clearForm();//clear form after data save
          this.getData();  //and get all data again
          this.alertMessage('Data Saved ','notice');
        } else {
          this.alertMessage('Data Saved Failed','notice');
        }
      });
  }

  update() //update selected data
  {
    this.service.update(this.myForm.value)
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          this.clearForm();//clear form after data save
          this.getData();  //and get all data again
          this.alertMessage('Data Updated ','notice');

        } else {
          this.alertMessage('Data Update Failed','notice');
        }
      });
  }

  delete() //delete selected data
  {
    this.service.delete(this.selection.selected[0].id)
      .subscribe(data => {
        let response: any = data;
        if (response.status == 200) {
          this.clearForm();//clear form after data save
          this.getData();  //and get all data again
          this.alertMessage('Data Removed ','notice');
        } else {
          this.alertMessage('Data Delete Failed','notice');
        }
      });
  }

  tableSelect(data: any) {
    if (this.selection.selected.length > 0) {
      this.myForm.patchValue(data);
    } else {
      this.myForm.reset();
    }
  }

  clearForm() //clear the form and selection
  {
    this.myForm.reset();
    this.selection.clear();
  }


  tableFilter(event: any) //Table filter
  {
    let filterValue = event.target.value;
    if (this.dataSource.data.length != 0) {
      filterValue = filterValue.trim();
      filterValue = filterValue.toLowerCase();
      this.dataSource.filter = filterValue;
    }
  }

  alertMessage(message: string, action: string) {
    this.snackBar.open(message, action, {
        duration: 4000,
        horizontalPosition: 'center',
        verticalPosition: 'top'
    });
}


}
