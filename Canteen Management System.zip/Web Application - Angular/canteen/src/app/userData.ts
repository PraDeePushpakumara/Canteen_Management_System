export class UserData {

    static userName='';
}
