/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.5.5-10.4.27-MariaDB : Database - canteen_management_system
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`canteen_management_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `canteen_management_system`;

/*Table structure for table `food_category` */

DROP TABLE IF EXISTS `food_category`;

CREATE TABLE `food_category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `food_category` */

insert  into `food_category`(`id`,`name`) values (1,'kottu'),(2,'cofee'),(3,'ride'),(4,'test');

/*Table structure for table `hibernate_sequence` */

DROP TABLE IF EXISTS `hibernate_sequence`;

CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `hibernate_sequence` */

insert  into `hibernate_sequence`(`next_val`) values (72);

/*Table structure for table `inventory` */

DROP TABLE IF EXISTS `inventory`;

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `inventory` */

insert  into `inventory`(`id`,`name`,`quantity`,`type`) values (64,'carrot',50,'Raw Material'),(65,'onion',100,'Raw Material');

/*Table structure for table `oder_details` */

DROP TABLE IF EXISTS `oder_details`;

CREATE TABLE `oder_details` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `estimate_time` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `oder_details` */

insert  into `oder_details`(`id`,`customer_name`,`date`,`estimate_time`,`status`) values (5,'pradeep','2013-12-12','20.06','accept'),(8,'pradeep','2013-12-12','20.06','cancelled'),(11,'pradeep','2013-12-12','20.06','picked'),(18,'pradeep','2023-05-17','2023-10-12','pending'),(21,'pradeep','2023-05-17','2023-10-12','cancelled'),(23,'pradep','2023-05-17','2023-10-12','accept'),(25,'test','2023-05-17','2023-10-12','ready'),(28,'test','2023-05-18','2023-10-12','pending'),(30,'tttt','2023-05-18','2023-10-12','pending'),(32,'tttt','2023-05-23','2023-10-12','pending'),(57,'test','2023-05-26','2023-10-12','pending'),(61,'test','2023-05-26','2023-10-12','pending'),(66,'','2023-05-26','22:3:8','pending'),(68,'','2023-05-26','22:07','pending'),(70,'','2023-05-26','22:09','pending');

/*Table structure for table `oder_item_details` */

DROP TABLE IF EXISTS `oder_item_details`;

CREATE TABLE `oder_item_details` (
  `id` int(11) NOT NULL,
  `price` double NOT NULL,
  `quntity` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5f01fuo143e720u05vjg99646` (`order_id`),
  KEY `FKaa5njkuokx11aueoww20xna3c` (`product_id`),
  CONSTRAINT `FK5f01fuo143e720u05vjg99646` FOREIGN KEY (`order_id`) REFERENCES `oder_details` (`id`),
  CONSTRAINT `FKaa5njkuokx11aueoww20xna3c` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `oder_item_details` */

insert  into `oder_item_details`(`id`,`price`,`quntity`,`order_id`,`product_id`) values (6,200,0,5,1),(7,300,0,5,2),(9,200,2,8,1),(12,200,2,11,1),(13,3400,5,11,2),(22,200,15,21,1),(24,200,1,23,1),(26,200,1,25,1),(27,200,1,25,2),(29,200,1,28,2),(31,200,1,30,2),(33,200,1,32,1),(58,200,1,57,1),(59,200,1,57,2),(60,50,1,57,55),(62,200,1,61,1),(63,200,1,61,2),(67,200,1,66,1),(69,200,1,68,2),(71,50,1,70,55);

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` double NOT NULL,
  `promotion_price` double NOT NULL,
  `rating` int(11) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `product` */

insert  into `product`(`id`,`category`,`name`,`price`,`promotion_price`,`rating`,`type`,`image`) values (1,'rice','rice ',200,200,5,'finished','https://www.sbs.com.au/food/sites/sbs.com.au.food/files/styles/full/public/au2_ep03_mum_s_malaysian_fried_rice_8894.jpg?itok=peSzLiq8'),(2,'bun','bun',200,200,5,'fisished','https://images.unsplash.com/photo-1592811773343-9abf0b1a6920?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8YnVufGVufDB8fDB8fA%3D%3D&w=1000&q=80'),(54,'Beverage','abc',100,100,4,'Raw Material','image'),(55,'Snack','wade',50,100,4,'Finished Food','image'),(56,'Snack','roti',300,300,4,'Finished Food','image');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `mobile_no` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user` */

insert  into `user`(`id`,`mobile_no`,`name`,`password`,`type`,`address`,`email`) values (14,5564654,'dfdsfdf','','','fsdfsdf','dfsfaf'),(15,2,'test','2','customer','hjhjfhj','fgghfhg'),(16,1,'tttt','1','customer','',''),(17,161644646,'isuru','Pasda23n',NULL,NULL,NULL),(34,11,'pradeep','11','customer','kottawa','abc@gmail.com'),(35,123,'abcd','123','admin','',''),(36,712345678,'pradeep','Pradeep123','admin','',''),(37,123,'abcd','Abcd123Q','user','',''),(38,123456789,'sadun','asdfqwer1Q','user','',''),(39,1234569875,'kasun','Padafag121','admin','',''),(40,111235647,'sdadaa','Pdada13214`','admin','',''),(41,114253652,'sampath','Padasd1324','user','','');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
